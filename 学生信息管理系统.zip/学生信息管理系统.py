import mysql.connector
from tkinter import *
from tkinter import scrolledtext
import tkinter as tk
import tkinter.messagebox as messagebox
import matplotlib.pyplot as plt
import numpy as np
from scipy import stats
import asyncio
import colorsys
import warnings


class LOGIN:
    def __init__(self, master):
        self.master = master
        self.create_widgets()

    def create_widgets(self):
        self.frame = tk.Frame(self.master)
        self.frame.place(x=0, y=0, width=500, height=300, anchor='nw')

        self.title = tk.Label(self.frame, text='学生信息管理系统登录页面', font=("Arial", 20, "bold"), fg="red")
        self.title.place(x=75, y=25, anchor='nw')

        self.account_label = tk.Label(self.frame, text="账号：")
        self.account_label.place(x=150, y=100, anchor='nw')
        self.account_entry = tk.Entry(self.frame)
        self.account_entry.place(x=210, y=100)

        self.password_label = tk.Label(self.frame, text="密码：")
        self.password_label.place(x=150, y=150, anchor='nw')
        self.password_entry = tk.Entry(self.frame, show='*')
        self.password_entry.place(x=210, y=150)

        self.login_button = tk.Button(self.frame, text='登    录', bg='silver', width=30,
                                      command=lambda: (self.save_data(), self.switch_window()))
        self.login_button.place(x=150, y=200)

    def save_data(self):
        global account
        global password
        account = self.account_entry.get()
        password = self.password_entry.get()

    def switch_window(self):
        query = '''SELECT COUNT(*) FROM user WHERE Account = %s AND Password = %s'''
        mycursor.execute(query, (self.account_entry.get(), self.password_entry.get()))
        result = mycursor.fetchone()
        if result[0] == 1:
            messagebox.showinfo("tip", "Login successful")
            new_window = tk.Toplevel(self.master)
            new_window.title('功能选择')
            new_window.geometry("900x700+300+50")
            sub_window = FOUNCTION(new_window)

            mycursor.close()
            mydb.close()

            self.login_button.config(state=DISABLED)
            self.master.withdraw()

        else:
            messagebox.showinfo("tip", "Login failed")


class FOUNCTION:
    def __init__(self, master):
        self.master = master
        self.create_widgets()

    def create_widgets(self):
        self.frame = tk.Frame(self.master)
        self.frame.pack()

        self.title = tk.Label(self.frame, text='学生信息管理功能页面', font=("Arial", 20, "bold"), fg="red")
        self.title.pack(padx=20, pady=20)

        self.button1 = tk.Button(self.frame, text='院系信息管理', bg='silver', width=30, command=self.switch_window1)
        self.button1.pack(padx=20, pady=20)

        self.button2 = tk.Button(self.frame, text='班级信息管理', bg='silver', width=30, command=self.switch_window2)
        self.button2.pack(padx=20, pady=20)

        self.button3 = tk.Button(self.frame, text='学生信息管理', bg='silver', width=30, command=self.switch_window3)
        self.button3.pack(padx=20, pady=20)

        self.button4 = tk.Button(self.frame, text='课程信息管理', bg='silver', width=30, command=self.switch_window4)
        self.button4.pack(padx=20, pady=20)

        self.button5 = tk.Button(self.frame, text='成绩信息管理', bg='silver', width=30, command=self.switch_window5)
        self.button5.pack(padx=20, pady=20)

        self.out_button = tk.Button(self.frame, text='退出系统', bg='silver', width=30, command=self.sign_out)
        self.out_button.pack(padx=20, pady=20)

    def sign_out(self):
        self.master.master.destroy()

    def switch_window1(self):
        new_window = tk.Toplevel(self.master)
        new_window.title('院系信息管理操作页面')
        new_window.geometry("900x700+300+50")
        sub_window = DETAIL1(new_window)
        self.master.withdraw()

    def switch_window2(self):
        new_window = tk.Toplevel(self.master)
        new_window.title('班级信息管理操作页面')
        new_window.geometry("900x700+300+50")
        sub_window = DETAIL2(new_window)
        self.master.withdraw()

    def switch_window3(self):
        new_window = tk.Toplevel(self.master)
        new_window.title('学生信息管理操作页面')
        new_window.geometry("900x700+300+50")
        sub_window = DETAIL3(new_window)
        self.master.withdraw()

    def switch_window4(self):
        new_window = tk.Toplevel(self.master)
        new_window.title('课程信息管理操作页面')
        new_window.geometry("900x700+300+50")
        sub_window = DETAIL4(new_window)
        self.master.withdraw()

    def switch_window5(self):
        new_window = tk.Toplevel(self.master)
        new_window.title('成绩信息管理操作页面')
        new_window.geometry("900x700+300+50")
        sub_window = DETAIL5(new_window)
        self.master.withdraw()


class DETAIL1:
    def __init__(self, master):
        self.mydb1 = mysql.connector.connect(
            host="localhost",
            user=account,
            password=password,
            database="student_management")
        self.cursor = self.mydb1.cursor()
        self.master = master
        self.create_widgets()

    def create_widgets(self):
        self.frame = tk.Frame(self.master)
        self.frame.place(x=0, y=0, width=900, height=700, anchor='nw')

        self.name_label = tk.Label(self.frame, text="院 系 信 息 查 询 操 作 页 面", font=("Arial", 20, "bold"), fg="red")
        self.name_label.place(x=250, y=25, anchor='nw')

        self.label = tk.Label(self.frame, text="注意：院系信息不可更改，只能进行查询操作", fg="red")
        self.label.place(x=50, y=100, anchor='nw')

        self.search_button = tk.Button(self.frame, text='查    询', bg='silver', width=30, command=self.search)
        self.search_button.place(x=50, y=150, anchor='nw')

        self.back_button = tk.Button(self.frame, text='返    回', bg='silver', width=30, command=self.back_to_main_window)
        self.back_button.place(x=50, y=200, anchor='nw')

        self.text = scrolledtext.ScrolledText(self.frame)
        self.text.place(x=300, y=100, width="500", height="500")
        self.text.insert(END, "\t\t    >>>欢迎使用学生信息管理系统<<<\n\t\t\t    Edition:  V1.1\n\t\t\t    Author:  白熊\n")

    def back_to_main_window(self):
        self.master.destroy()
        self.master.master.deiconify()

    def search(self):
        query = "SELECT * FROM department"
        self.cursor.execute(query)
        results = self.cursor.fetchall()
        self.text.insert(END, "显示结果为:\n")
        self.text.insert(END, "院系ID\t\t院系名称\n")
        for result in results:
            self.text.insert(END, "{}\t\t{}\n".format(result[0], result[1].decode("utf-8")))
        self.text.configure(state=DISABLED)
        self.search_button.config(state=DISABLED)
        self.cursor.close()
        self.mydb1.close()


class DETAIL2:
    def __init__(self, master):
        self.mydb1 = mysql.connector.connect(
            host="localhost",
            user=account,
            password=password,
            database="student_management")
        self.cursor = self.mydb1.cursor()
        self.master = master
        self.create_widgets()

    def create_widgets(self):
        self.frame = tk.Frame(self.master)
        self.frame.place(x=0, y=0, width=900, height=700, anchor='nw')

        self.name_label = tk.Label(self.frame, text="班 级 信 息 查 询 操 作 页 面", font=("Arial", 20, "bold"), fg="red")
        self.name_label.place(x=250, y=25, anchor='nw')

        self.label = tk.Label(self.frame, text="注意：班级信息不可更改，只能进行查询操作", fg="red")
        self.label.place(x=50, y=100, anchor='nw')

        self.search_button = tk.Button(self.frame, text='查    询', bg='silver', width=30, command=self.search)
        self.search_button.place(x=50, y=150, anchor='nw')

        self.back_button = tk.Button(self.frame, text='返    回', bg='silver', width=30, command=self.back_to_main_window)
        self.back_button.place(x=50, y=200, anchor='nw')

        self.text = scrolledtext.ScrolledText(self.frame)
        self.text.place(x=300, y=100, width="500", height="500")
        self.text.insert(END, "\t\t    >>>欢迎使用学生信息管理系统<<<\n\t\t\t    Edition:  V1.1\n\t\t\t    Author:  白熊\n")

    def back_to_main_window(self):
        self.master.destroy()
        self.master.master.deiconify()

    def search(self):
        query = "SELECT * FROM class"
        self.cursor.execute(query)
        results = self.cursor.fetchall()
        self.text.insert(END, "查询结果为:\n")
        self.text.insert(END, "班级名称\t\t所属院系ID\n")
        for result in results:
            self.text.insert(END, "{}\t\t{}\n".format(result[0].decode("utf-8"), result[1]))
        self.text.configure(state=DISABLED)
        self.search_button.config(state=DISABLED)
        self.cursor.close()
        self.mydb1.close()


class DETAIL3:
    def __init__(self, master):
        self.mydb1 = mysql.connector.connect(
            host="localhost",
            user=account,
            password=password,
            database="student_management")
        self.cursor = self.mydb1.cursor()
        self.master = master
        self.create_widgets()

    def create_widgets(self):
        self.frame = tk.Frame(self.master)
        self.frame.place(x=0, y=0, width=900, height=700, anchor='nw')

        self.name_label = tk.Label(self.frame, text="学 生 信 息 管 理 操 作 页 面", font=("Arial", 20, "bold"), fg="red")
        self.name_label.place(x=250, y=25, anchor='nw')

        self.Sid_label = tk.Label(self.frame, text="学号：")
        self.Sid_label.place(x=50, y=100, anchor='nw')
        self.Sid_entry = tk.Entry(self.frame)
        self.Sid_entry.place(x=110, y=100, anchor='nw')

        self.Sname_label = tk.Label(self.frame, text="姓名：")
        self.Sname_label.place(x=50, y=150, anchor='nw')
        self.Sname_entry = tk.Entry(self.frame)
        self.Sname_entry.place(x=110, y=150, anchor='nw')

        self.Ssex_label = tk.Label(self.frame, text="性别：")
        self.Ssex_label.place(x=50, y=200, anchor='nw')
        self.Ssex_entry = tk.Entry(self.frame)
        self.Ssex_entry.place(x=110, y=200, anchor='nw')

        self.Sage_label = tk.Label(self.frame, text="年龄：")
        self.Sage_label.place(x=50, y=250, anchor='nw')
        self.Sage_entry = tk.Entry(self.frame)
        self.Sage_entry.place(x=110, y=250, anchor='nw')

        self.Cname_label = tk.Label(self.frame, text="所属班级：")
        self.Cname_label.place(x=50, y=300, anchor='nw')
        self.Cname_entry = tk.Entry(self.frame)
        self.Cname_entry.place(x=110, y=300, anchor='nw')

        self.text = scrolledtext.ScrolledText(self.frame)
        self.text.place(x=300, y=100, width="500", height="500")
        self.text.insert(END, "\t\t    >>>欢迎使用学生信息管理系统<<<\n\t\t\t    Edition:  V1.1\n\t\t\t    Author:  白熊\n")

        self.add_button = tk.Button(self.frame, text='添    加', bg='silver', width=30, command=self.add)
        self.add_button.place(x=50, y=350, anchor='nw')

        self.updata_button = tk.Button(self.frame, text='修    改', bg='silver', width=30, command=self.updata)
        self.updata_button.place(x=50, y=400, anchor='nw')

        self.delet_button = tk.Button(self.frame, text='删    除', bg='silver', width=30, command=self.delet)
        self.delet_button.place(x=50, y=450, anchor='nw')

        self.search_button = tk.Button(self.frame, text='查询（只支持姓名和性别的模糊查找）', bg='silver', width=30, command=self.search)
        self.search_button.place(x=50, y=500, anchor='nw')

        self.show_button = tk.Button(self.frame, text='显示所有学生信息', bg='silver', width=30, command=self.show)
        self.show_button.place(x=50, y=550, anchor='nw')

        self.back_button = tk.Button(self.frame, text='返    回', bg='silver', width=30, command=self.back_to_main_window)
        self.back_button.place(x=50, y=600, anchor='nw')

    def add(self):
        result1 = messagebox.askyesno("tip", "WARNING！！！\nDo you want to save changes?")

        if result1:
            query = '''INSERT 
                        INTO student(Sid,Sname,Ssex,Sage,Cname)
                        VALUES(%s, %s, %s, %s, %s)'''
            val = (self.Sid_entry.get(), self.Sname_entry.get(),
                   self.Ssex_entry.get(), self.Sage_entry.get(),
                   self.Cname_entry.get())
            if all(val):
                try:
                    self.cursor.execute(query, val)
                    self.text.insert(END, "\n添加成功\n")
                except mysql.connector.Error as err:
                    self.text.insert(END, "\n添加失败：{}\n".format(err))
            else:
                self.text.insert(END, "\n任何信息都不能为空，否则无法添加\n")
            self.mydb1.commit()
        else:
            self.text.insert(END, "\n添加操作已取消\n")

    def updata(self):
        result1 = messagebox.askyesno("tip", "WARNING！！！\nDo you want to save changes?")

        if result1:
            query1 = '''UPDATE student 
                        SET Sid = %s, Sname = %s, Ssex = %s, Sage = %s, Cname = %s 
                        WHERE Sid = %s'''
            val1 = (self.Sid_entry.get(), self.Sname_entry.get(), self.Ssex_entry.get(),
                    self.Sage_entry.get(), self.Cname_entry.get(), self.Sid_entry.get())

            query2 = '''SELECT * FROM student WHERE Sid = %s'''
            Sid = self.Sid_entry.get()
            val2 = (Sid,)
            self.cursor.execute(query2, val2)
            result2 = self.cursor.fetchone()
            if result2:
                try:
                    self.cursor.execute(query1, val1)
                    self.text.insert(END, "\n修改成功\n")
                except mysql.connector.Error as err:
                    self.text.insert(END, "\n修改失败：{}\n".format(err))
            else:
                self.text.insert(END, "\n请检查学号是否正确，否则无法修改\n")
            self.mydb1.commit()
        else:
            self.text.insert(END, "\n修改操作已取消\n")

    def delet(self):
        result1 = messagebox.askyesno("tip", "WARNING！！！\nDo you want to save changes?")

        if result1:
            query1 = '''DELETE
                        FROM student
                        WHERE Sid = %s'''
            Sid = self.Sid_entry.get()
            val1 = (Sid,)

            query2 = '''SELECT * FROM student WHERE Sid = %s'''
            Sid = self.Sid_entry.get()
            val2 = (Sid,)
            self.cursor.execute(query2, val2)
            result = self.cursor.fetchone()
            if result:
                try:
                    self.cursor.execute(query1, val1)
                    self.text.insert(END, "\n删除成功\n")
                except mysql.connector.Error as err:
                    self.text.insert(END, "\n删除失败：{}\n".format(err))
            else:
                self.text.insert(END, "\n学生学号不能为空并且需要是已存在的，否则无法删除\n")
            self.mydb1.commit()
        else:
            self.text.insert(END, "\n删除操作已取消\n")

    def search(self):
        query = '''SELECT * FROM student 
                    JOIN class ON student.Cname = class.Cname
                    JOIN department ON class.Did = department.Did
                    WHERE department.Did = %s AND Sname LIKE %s AND Ssex LIKE %s'''
        val = (account, "%" + self.Sname_entry.get() + "%", self.Ssex_entry.get())
        if all(val):
            try:
                self.cursor.execute(query, val)
                self.text.insert(END, "\n查询结果：\n")
                results = self.cursor.fetchall()
                self.text.insert(END, "学号\t姓名\t性别\t年龄\t所属班级\n")
                for result in results:
                    self.text.insert(END, "{}\t{}\t{}\t{}\t{}\n".format(result[0], result[1].decode("utf-8"),
                                                                        result[2].decode("utf-8"),
                                                                        result[3].decode("utf-8"),
                                                                        result[4].decode("utf-8")))

            except mysql.connector.Error as err:
                self.text.insert(END, "\n查询失败：{}\n".format(err))
        else:
            self.text.insert(END, "\n姓名栏和性别栏都不能为空，否则无法查询\n")

    def show(self):
        query = '''SELECT * FROM student
                    JOIN class ON student.Cname = class.Cname
                    JOIN department ON class.Did = department.Did
                    WHERE department.Did = %s'''
        val = (account,)
        self.cursor.execute(query, val)
        results = self.cursor.fetchall()
        self.text.insert(END, "\n显示结果为:\n")
        self.text.insert(END, "学号\t姓名\t性别\t年龄\t所属班级\n")
        for result in results:
            self.text.insert(END, "{}\t{}\t{}\t{}\t{}\n".format(result[0], result[1].decode("utf-8"),
                                                                result[2].decode("utf-8"),
                                                                result[3].decode("utf-8"),
                                                                result[4].decode("utf-8")))

    def back_to_main_window(self):
        self.cursor.close()
        self.mydb1.close()
        self.master.destroy()
        self.master.master.deiconify()


class DETAIL4:
    def __init__(self, master):
        self.mydb1 = mysql.connector.connect(
            host="localhost",
            user=account,
            password=password,
            database="student_management")
        self.cursor = self.mydb1.cursor()
        self.master = master
        self.create_widgets()

    def create_widgets(self):
        self.frame = tk.Frame(self.master)
        self.frame.place(x=0, y=0, width=900, height=700, anchor='nw')

        self.name_label = tk.Label(self.frame, text="课 程 信 息 管 理 操 作 页 面", font=("Arial", 20, "bold"), fg="red")
        self.name_label.place(x=250, y=25, anchor='nw')

        self.Lname_label = tk.Label(self.frame, text="课程名称：")
        self.Lname_label.place(x=50, y=100, anchor='nw')
        self.Lname_entry = tk.Entry(self.frame)
        self.Lname_entry.place(x=110, y=100, anchor='nw')

        self.Lcredit_label = tk.Label(self.frame, text="学分：")
        self.Lcredit_label.place(x=50, y=150, anchor='nw')
        self.Lcredit_entry = tk.Entry(self.frame)
        self.Lcredit_entry.place(x=110, y=150, anchor='nw')

        self.text = scrolledtext.ScrolledText(self.frame)
        self.text.place(x=300, y=100, width="500", height="500")
        self.text.insert(END, "\t\t    >>>欢迎使用学生信息管理系统<<<\n\t\t\t    Edition:  V1.1\n\t\t\t    Author:  白熊\n")

        self.show_button = tk.Button(self.frame, text='显示所有课程信息', bg='silver', width=30, command=self.show)
        self.show_button.place(x=50, y=200, anchor='nw')

        self.add_button = tk.Button(self.frame, text='添    加', bg='silver', width=30, command=self.add)
        self.add_button.place(x=50, y=250, anchor='nw')

        self.search_button = tk.Button(self.frame, text='查询（支持对课程名的模糊查找）', bg='silver', width=30, command=self.search)
        self.search_button.place(x=50, y=300, anchor='nw')

        self.updata_button = tk.Button(self.frame, text='修    改', bg='silver', width=30, command=self.updata)
        self.updata_button.place(x=50, y=350, anchor='nw')

        self.delete_button = tk.Button(self.frame, text='删    除（只用写课程名）', bg='silver', width=30, command=self.delete)
        self.delete_button.place(x=50, y=400, anchor='nw')

        self.back_button = tk.Button(self.frame, text='返    回', bg='silver', width=30, command=self.back_to_main_window)
        self.back_button.place(x=50, y=450, anchor='nw')

    def show(self):
        query = '''SELECT * FROM lesson'''
        self.cursor.execute(query)
        results = self.cursor.fetchall()
        self.text.insert(END, "\n显示结果为:\n")
        self.text.insert(END, "课程名称\t\t学分\n")
        for result in results:
            self.text.insert(END, "{}\t\t{}\n".format(result[0].decode("utf-8"), result[1]))

    def add(self):
        result1 = messagebox.askyesno("tip", "WARNING！！！\nDo you want to save changes?")

        if result1:
            query = '''INSERT INTO lesson(Lname, Lcredit)
                        VALUES(%s, %s)'''
            val = (self.Lname_entry.get(), self.Lcredit_entry.get())
            if all(val):
                try:
                    self.cursor.execute(query, val)
                    self.text.insert(END, "\n添加成功\n")
                except mysql.connector.Error as err:
                    self.text.insert(END, "\n添加失败：{}\n".format(err))
            else:
                self.text.insert(END, "\n任何信息都不能为空，否则无法添加\n")
            self.mydb1.commit()
        else:
            self.text.insert(END, "\n添加操作已取消\n")

    def search(self):
        query = '''SELECT * FROM lesson WHERE Lname LIKE %s'''
        val = ("%" + self.Lname_entry.get() + "%",)
        if val != ("%%",):
            try:
                self.cursor.execute(query, val)
                self.text.insert(END, "\n查询结果：\n")
                results = self.cursor.fetchall()
                self.text.insert(END, "课程名称\t\t学分\n")
                for result in results:
                    self.text.insert(END, "{}\t\t{}\n".format(result[0].decode("utf-8"), result[1]))
            except mysql.connector.Error as err:
                self.text.insert(END, "\n查询失败：{}\n".format(err))
        else:
            self.text.insert(END, "\n课程名不能为空，否则无法查询\n")
        self.mydb1.commit()

    def updata(self):
        result1 = messagebox.askyesno("tip", "WARNING！！！\nDo you want to save changes?")

        if result1:
            query1 = '''UPDATE lesson SET Lname = %s, Lcredit = %s 
                        WHERE Lname = %s'''
            val1 = (self.Lname_entry.get(), self.Lcredit_entry.get(), self.Lname_entry.get())

            query2 = '''SELECT * FROM lesson WHERE Lname = %s'''
            Sid = self.Lname_entry.get()
            val2 = (Sid,)
            self.cursor.execute(query2, val2)
            result = self.cursor.fetchone()
            if result:
                try:
                    self.cursor.execute(query1, val1)
                    self.text.insert(END, "\n修改成功\n")
                except mysql.connector.Error as err:
                    self.text.insert(END, "\n修改失败：{}\n".format(err))
            else:
                self.text.insert(END, "\n请检查课程名称是否正确，否则无法修改\n")
            self.mydb1.commit()
        else:
            self.text.insert(END, "\n修改操作已取消\n")

    def delete(self):
        result1 = messagebox.askyesno("tip", "WARNING！！！\nDo you want to save changes?")

        if result1:
            query1 = '''DELETE
                        FROM lesson
                        WHERE Lname = %s'''
            Lname = self.Lname_entry.get()
            val1 = (Lname,)

            query2 = '''SELECT * FROM lesson WHERE Lname = %s'''
            Lname = self.Lname_entry.get()
            val2 = (Lname,)
            self.cursor.execute(query2, val2)
            result = self.cursor.fetchone()
            if result:
                try:
                    self.cursor.execute(query1, val1)
                    self.text.insert(END, "\n删除成功\n")
                except mysql.connector.Error as err:
                    self.text.insert(END, "\n删除失败：{}\n".format(err))
            else:
                self.text.insert(END, "\n课程名称不能为空并且需要是已存在的，否则无法删除\n")
            self.mydb1.commit()
        else:
            self.text.insert(END, "\n删除操作已取消\n")

    def back_to_main_window(self):
        self.cursor.close()
        self.mydb1.close()
        self.master.destroy()
        self.master.master.deiconify()


class DETAIL5:
    def __init__(self, master):
        self.mydb1 = mysql.connector.connect(
            host="localhost",
            user=account,
            password=password,
            database="student_management")
        self.cursor = self.mydb1.cursor()
        self.master = master
        self.create_widgets()

    def create_widgets(self):
        self.frame = tk.Frame(self.master)
        self.frame.place(x=0, y=0, width=900, height=700, anchor='nw')

        self.name_label = tk.Label(self.frame, text="成 绩 信 息 管 理 操 作 页 面", font=("Arial", 20, "bold"), fg="red")
        self.name_label.place(x=250, y=25, anchor='nw')

        self.Sid_label = tk.Label(self.frame, text="学号：")
        self.Sid_label.place(x=50, y=100, anchor='nw')
        self.Sid_entry = tk.Entry(self.frame)
        self.Sid_entry.place(x=110, y=100, anchor='nw')

        self.Lname_label = tk.Label(self.frame, text="课程名称：")
        self.Lname_label.place(x=50, y=150, anchor='nw')
        self.Lname_entry = tk.Entry(self.frame)
        self.Lname_entry.place(x=110, y=150, anchor='nw')

        self.Grade_label = tk.Label(self.frame, text="得分：")
        self.Grade_label.place(x=50, y=200, anchor='nw')
        self.Grade_entry = tk.Entry(self.frame)
        self.Grade_entry.place(x=110, y=200, anchor='nw')

        self.text = scrolledtext.ScrolledText(self.frame)
        self.text.place(x=300, y=100, width="500", height="500")
        self.text.insert(END, "\t\t    >>>欢迎使用学生信息管理系统<<<\n\t\t\t    Edition:  V1.1\n\t\t\t    Author:  白熊\n")

        self.show_button = tk.Button(self.frame, text='显示所有成绩信息', bg='silver', width=30, command=self.show)
        self.show_button.place(x=50, y=250, anchor='nw')

        self.add_button = tk.Button(self.frame, text='添    加', bg='silver', width=30, command=self.add)
        self.add_button.place(x=50, y=300, anchor='nw')

        self.search_button = tk.Button(self.frame, text='查    询(需要提供学号和课程名称)', bg='silver', width=30,
                                       command=self.search)
        self.search_button.place(x=50, y=350, anchor='nw')

        self.updata_button = tk.Button(self.frame, text='修    改', bg='silver', width=30, command=self.updata)
        self.updata_button.place(x=50, y=400, anchor='nw')

        self.delete_button = tk.Button(self.frame, text='删    除（只需写学号和课程名程）', bg='silver', width=30,
                                       command=self.delete)
        self.delete_button.place(x=50, y=450, anchor='nw')

        self.button1 = tk.Button(self.frame, text='课程平均分与不及格率（需写课程名称）', bg='silver', width=30, command=self.button1)
        self.button1.place(x=50, y=500, anchor='nw')

        self.button2 = tk.Button(self.frame, text='课程分数排序（降序排列）', bg='silver', width=30, command=self.button2)
        self.button2.place(x=50, y=550, anchor='nw')

        self.back_button = tk.Button(self.frame, text='返    回', bg='silver', width=30, command=self.back_to_main_window)
        self.back_button.place(x=50, y=600, anchor='nw')

    def show(self):
        query = '''SELECT * FROM grade
                    JOIN student ON student.Sid = grade.Sid
                    JOIN class ON  class.Cname = student.Cname
                    JOIN department ON  department.Did = class.Did
                    WHERE department.Did = %s '''
        val = (account,)
        self.cursor.execute(query, val)
        results = self.cursor.fetchall()
        self.text.insert(END, "\n显示结果为:\n")
        self.text.insert(END, "学号\t课程名称\t\t得分\n")
        for result in results:
            self.text.insert(END, "{}\t{}\t\t{}\n".format(result[0], result[1].decode("utf-8"), result[2]))

    def add(self):
        result1 = messagebox.askyesno("tip", "WARNING！！！\nDo you want to save changes?")

        if result1:
            query = '''INSERT INTO grade(Sid, Lname, Grade)
                        VALUES(%s, %s, %s)'''
            val = (self.Sid_entry.get(), self.Lname_entry.get(), self.Grade_entry.get())
            if all(val):
                try:
                    self.cursor.execute(query, val)
                    self.text.insert(END, "\n添加成功\n")
                except mysql.connector.Error as err:
                    self.text.insert(END, "\n添加失败：{}\n".format(err))
            else:
                self.text.insert(END, "\n任何信息都不能为空，否则无法添加\n")
            self.mydb1.commit()
        else:
            self.text.insert(END, "\n添加操作已取消\n")

    def search(self):
        query = '''SELECT * FROM grade WHERE Sid = %s AND Lname = %s'''
        val = (self.Sid_entry.get(), self.Lname_entry.get())
        if all(val):
            try:
                self.cursor.execute(query, val)
                self.text.insert(END, "\n查询结果：\n")
                results = self.cursor.fetchall()
                self.text.insert(END, "学号\t课程名称\t\t得分\n")
                for result in results:
                    self.text.insert(END, "{}\t{}\t\t{}\n".format(result[0], result[1].decode("utf-8"), result[2]))
            except mysql.connector.Error as err:
                self.text.insert(END, "\n查询失败：{}\n".format(err))
        else:
            self.text.insert(END, "\n学号和课程名不能为空，否则无法查询\n")
        self.mydb1.commit()

    def updata(self):
        result1 = messagebox.askyesno("tip", "WARNING！！！\nDo you want to save changes?")

        if result1:
            query1 = '''UPDATE grade SET Sid =%s, Lname = %s, Grade = %s
                         WHERE Sid =%s AND Lname = %s'''
            val1 = (self.Sid_entry.get(), self.Lname_entry.get(), self.Grade_entry.get(),
                    self.Sid_entry.get(), self.Lname_entry.get())

            query2 = '''SELECT * FROM grade WHERE Sid =%s AND Lname = %s'''
            val2 = (self.Sid_entry.get(), self.Lname_entry.get())
            self.cursor.execute(query2, val2)
            result = self.cursor.fetchone()
            if result:
                try:
                    self.cursor.execute(query1, val1)
                    self.text.insert(END, "\n修改成功\n")
                except mysql.connector.Error as err:
                    self.text.insert(END, "\n修改失败：{}\n".format(err))
            else:
                self.text.insert(END, "\n请检查学号和课程名称是否正确，否则无法修改\n")
            self.mydb1.commit()
        else:
            self.text.insert(END, "\n修改操作已取消\n")

    def delete(self):
        result1 = messagebox.askyesno("tip", "WARNING！！！\nDo you want to save changes?")

        if result1:
            query1 = '''DELETE
                                FROM grade
                                WHERE Sid = %s AND Lname = %s'''
            val1 = (self.Sid_entry.get(), self.Lname_entry.get())

            query2 = '''SELECT * FROM grade WHERE Sid = %s AND Lname = %s'''
            val2 = (self.Sid_entry.get(), self.Lname_entry.get())
            self.cursor.execute(query2, val2)
            result = self.cursor.fetchone()
            if result:
                try:
                    self.cursor.execute(query1, val1)
                    self.text.insert(END, "\n删除成功\n")
                except mysql.connector.Error as err:
                    self.text.insert(END, "\n删除失败：{}\n".format(err))
            else:
                self.text.insert(END, "\n学号和课程名称不能为空并且需要是已存在的，否则无法删除\n")
            self.mydb1.commit()
        else:
            self.text.insert(END, "\n删除操作已取消\n")

    def button1(self):
        query1 = '''SELECT AVG(Grade) FROM grade WHERE Lname = %s'''
        val1 = (self.Lname_entry.get(),)
        if all(val1):
            try:
                self.cursor.execute(query1, val1)
                self.text.insert(END, "\n计算结果：\n")
                results0 = self.cursor.fetchall()
                self.text.insert(END, "平均分：")
                for result0 in results0:
                    self.text.insert(END, "{}\n".format(result0[0]))
            except mysql.connector.Error as err:
                self.text.insert(END, "\n平均分计算失败：{}\n".format(err))
        else:
            self.text.insert(END, "\n课程名不能为空，否则无法计算平均分\n")

        query2 = '''SELECT COUNT(Grade) FROM grade
                    JOIN student ON student.Sid = grade.Sid
                    JOIN class ON  class.Cname = student.Cname
                    JOIN department ON  department.Did = class.Did
                    WHERE Lname = %s AND Grade < 60 AND department.Did = %s'''
        query3 = '''SELECT COUNT(Grade) FROM grade 
                    JOIN student ON student.Sid = grade.Sid
                    JOIN class ON  class.Cname = student.Cname
                    JOIN department ON  department.Did = class.Did
                    WHERE Lname = %s AND department.Did = %s'''
        query4 = '''SELECT Grade FROM grade 
                    JOIN student ON student.Sid = grade.Sid
                    JOIN class ON  class.Cname = student.Cname
                    JOIN department ON  department.Did = class.Did
                    WHERE Lname = %s AND department.Did = %s'''
        val2 = (self.Lname_entry.get(), account)
        if all(val2):
            try:
                self.cursor.execute(query2, val2)
                results1 = self.cursor.fetchall()
                self.cursor.execute(query3, val2)
                results2 = self.cursor.fetchall()
                self.cursor.execute(query4, val2)
                results3 = self.cursor.fetchall()
                scores = [row[0] for row in results3]

                self.text.insert(END, "不及格率：")
                for result1 in results1:
                    for result2 in results2:
                        self.text.insert(END, "{}\n".format(result1[0] / result2[0]))

                plt.rcParams['font.sans-serif'] = ['SimHei']
                plt.rcParams['axes.unicode_minus'] = False

                fig = plt.figure(figsize=(14, 6))
                fig.subplots_adjust(left=0.1, right=0.9, bottom=0.1, top=0.9)

                ax1 = fig.add_subplot(1, 2, 1)
                bins = np.arange(0, 110, 10)
                hist, _ = np.histogram(scores, bins=bins)
                ax1.bar(bins[:-1] + 5, hist, width=8, edgecolor='black', linestyle='dashed')
                ax1.set_xlabel('得分')
                ax1.set_ylabel('该分段人数')
                ax1.set_title("{}成绩分布直方图".format(self.Lname_entry.get()))

                ax2 = fig.add_subplot(1, 2, 2)
                mean = np.mean(scores)
                std = np.std(scores)
                x = np.linspace(mean - 3 * std, mean + 3 * std, 100)
                y = stats.norm.pdf(x, mean, std)
                ax2.plot(x, y)
                ax2.set_xlabel('得分')
                ax2.set_ylabel('概率密度')
                ax2.set_title("{}成绩正态分布图".format(self.Lname_entry.get()))
                ax2.axvline(x=mean, color='r', linestyle='--')

                plt.show()

            except mysql.connector.Error as err:
                self.text.insert(END, "\n不及格率计算失败：{}\n".format(err))
        else:
            self.text.insert(END, "\n课程名不能为空，否则无法计算不及格率\n")

    def button2(self):
        query = '''SELECT * FROM grade 
                    JOIN student ON student.Sid = grade.Sid
                    JOIN class ON  class.Cname = student.Cname
                    JOIN department ON  department.Did = class.Did
                    WHERE Lname = %s AND department.Did = %s ORDER BY Grade DESC'''
        val = (self.Lname_entry.get(), account)
        if all(val):
            try:
                self.cursor.execute(query, val)
                self.text.insert(END, "\n排序结果：\n")
                results = self.cursor.fetchall()
                self.text.insert(END, "学号\t课程名称\t\t得分\n")
                for result in results:
                    self.text.insert(END, "{}\t{}\t\t{}\n".format(result[0], result[1].decode("utf-8"), result[2]))
            except mysql.connector.Error as err:
                self.text.insert(END, "\n排序失败：{}\n".format(err))
        else:
            self.text.insert(END, "\n课程名不能为空，否则无法排序\n")

    def back_to_main_window(self):
        self.cursor.close()
        self.mydb1.close()
        self.master.destroy()
        self.master.master.deiconify()


async def run():
    global mycursor
    global mydb
    mydb = mysql.connector.connect(
        host="你的host名字",
        user="账号",
        password="密码",
        database="要连接的数据库")
    mycursor = mydb.cursor()
    root = tk.Tk()
    root.title("登录页面")
    root.geometry("500x300+500+200")
    root.resizable(False, False)
    user = LOGIN(root)
    root.mainloop()


# main函数里暂时只布置了两个task任务，可根据需要增减
async def main():
    warnings.filterwarnings('ignore', message='invalid value encountered in divide')
    print(f"{rgb_to_ansi(*RED)}\n   ATTENTION!!!")
    print(f"{rgb_to_ansi(*GREEN)}system all online\n")
    task1 = asyncio.create_task(run())
    task2 = asyncio.create_task(run())
    await task1
    await task2
    print(f"{rgb_to_ansi(*CYAN)}task1 completed:", task1.done())
    print(f'task2 completed: {task2.done()}')
    print(f'task1 errors: {task1.result()}')
    print(f'task2 errors: {task2.result()}')
    print(f"{rgb_to_ansi(*GREEN)}\nsystem all offline")


def rgb_to_ansi(r, g, b):
    h, s, v = colorsys.rgb_to_hsv(r / 255, g / 255, b / 255)
    return f'\033[38;2;{int(r)};{int(g)};{int(b)}m'


RED = (255, 0, 0)
GREEN = (0, 255, 0)
CYAN = (0, 255, 255)
mycursor = None
mydb = None
account = 0
password = 0

asyncio.run(main())